# crypto-market-analyst-llama-index

# Primero ejecutar get_crypto_news.py, luego index_news.py y por ultimo app.py y despues introducir el comando: '& "ruta\crypto-market-analyst-llama-index\venv\Scripts\python.exe" -m streamlit run ruta/crypto-market-analyst-llama-index/app.py' en la terminal

# Se necesita una OpenAI key, puedes usar la tuya en keys.py