import requests
import os
from bs4 import BeautifulSoup

# URLS necesarias
url_bitcoin_news = "https://cryptonews.com/news/bitcoin-news/"
url_ethereum_news = "https://cryptonews.com/news/ethereum-news/"
url_altcoins_news = "https://cryptonews.com/news/altcoin-news/"
urls = [None, None, None]
urls[0] = url_bitcoin_news
urls[1] = url_ethereum_news
urls[2] = url_altcoins_news


# Vaciar carpeta news
carpeta = "news"
if  os.path.exists(carpeta):

    # Obtener la lista de archivos en la carpeta
    archivos_en_carpeta = os.listdir(carpeta)

    # Eliminar cada archivo en la carpeta
    for archivo in archivos_en_carpeta:
        ruta_completa = os.path.join(carpeta, archivo)
        os.remove(ruta_completa)

# Para cada URL obtener las URLs de cada articulo y guardar el contenido de todos los articulos
for url in urls: 

    response = requests.get(url)

    # Parsear el contenido HTML
    soup = BeautifulSoup(response.text, "html.parser")

    news_elements = soup.find_all('a', class_="article__title article__title--lg article__title--featured mb-20")
    news_elements += soup.find_all('a', class_="article__image article__image--sm-wider mb-15")
    href = ""
    i = 1

    # Por separado se coge el contenido de cada articulo
    for elemento in news_elements:
        html_str = str(elemento)

        # Analizar el HTML utilizando BeautifulSoup
        soup = BeautifulSoup(html_str, 'html.parser')

        # Encontrar el atributo href en la etiqueta <a>
        href = soup.find('a')['href']
        url_article = href
        response = requests.get(url_article)

        # Parsear el contenido HTML
        soup = BeautifulSoup(response.text, "html.parser")
        elemento_clase = soup.find(class_="article-single__content category_contents_details")
        titulo_principal = elemento_clase.find('h1').text if soup.find('h1') else ""

        # Obtener el contenido de todas las etiquetas <p> y concxatenarlo
        parrafos_concatenados = " ".join([p.text for p in elemento_clase.find_all('p')])

        # Eliminamos la frase de publicidad comun en todos los articulos
        eliminar_publicidad = "Stay up-to-date with the world of digital assets by exploring our handpicked collection of the best 15 alternative cryptocurrencies and ICO projects to keep an eye on in 2023. Our list has been curated by professionals from Industry Talk and Cryptonews, ensuring expert advice and critical insights for your cryptocurrency investments. Take advantage of this opportunity to discover the potential of these digital assets and keep yourself informed. Disclaimer: Cryptocurrency projects endorsed in this article are not the financial advice of the publishing author or publication – cryptocurrencies are highly volatile investments with considerable risk, always do your own research.  A quick 3min read about today's crypto news!"
        parrafos_bien = parrafos_concatenados.replace(eliminar_publicidad, "")

        # Guardamos titulo y parrafos
        contenido_completo = titulo_principal + " " + parrafos_bien
        
        carpeta = "news"

        # Nombre del archivo HTML
        if(url == "https://cryptonews.com/news/bitcoin-news/"):
            nombre_archivo = "article_BTC_" + str(i) + ".html"
        else: 
            if(url == "https://cryptonews.com/news/ethereum-news/"):
                nombre_archivo = "article_ETH_" + str(i) + ".html"
            else:
                nombre_archivo = "article_altcoin_" + str(i) + ".html"

        # Ruta completa del archivo HTML
        ruta_completa = f"{carpeta}/{nombre_archivo}"

        # Crear la carpeta si no existe
        if not os.path.exists(carpeta):
            os.makedirs(carpeta)

        # Escribir el contenido en el archivo HTML
        with open(ruta_completa, 'w', encoding='utf-8') as archivo:
            archivo.write(contenido_completo)

        i+=1

# Todo OK
print("Articulos guardados correctamente")


