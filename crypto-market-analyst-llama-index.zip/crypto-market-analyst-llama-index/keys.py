# openai key
OPENAI_API_KEY = "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"

# # Configuración de las credenciales de Twitter
# consumer_key = "x"
# consumer_secret = "x"
# access_token = "x"
# access_token_secret = "x"

# # Configuración de las credenciales de Llama Index
# bearer_token = "x"