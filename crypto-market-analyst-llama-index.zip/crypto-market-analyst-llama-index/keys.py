# openai key
OPENAI_API_KEY = "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"

# # Configuración de las credenciales de Twitter
# consumer_key = "x"
# consumer_secret = "x"
# access_token = "x"
# access_token_secret = "x"

# # Configuración de las credenciales de Llama Index
# bearer_token = "x"