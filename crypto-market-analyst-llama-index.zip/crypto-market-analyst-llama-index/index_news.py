import os, keys, llama_index

from llama_index import GPTVectorStoreIndex, SimpleDirectoryReader

os.environ['OPENAI_API_KEY'] = keys.OPENAI_API_KEY

# Cargar noticias de la carpeta news
documents = SimpleDirectoryReader('news').load_data()

# Crear índice de vectores a partir de los documentos cargados.
index = GPTVectorStoreIndex.from_documents(documents)

# Guardar los datos del índice, para que puedan ser utilizados posteriormente sin necesidad de volver a crear el índice desde cero
index.storage_context.persist()