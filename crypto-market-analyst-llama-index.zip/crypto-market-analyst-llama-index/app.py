import os, keys, llama_index
from llama_index import GPTVectorStoreIndex, StorageContext, load_index_from_storage
os.environ['OPENAI_API_KEY'] = keys.OPENAI_API_KEY

import streamlit as st
from llama_index import ServiceContext, LLMPredictor
from langchain.llms import OpenAI

from llama_index import download_loader
import tweepy 

# # TWITTER. No disponible, ahora es de pago

# # Configuración de las credenciales de Twitter
# consumer_key = config.consumer_key
# consumer_secret = config.consumer_secret
# access_token = config.access_token
# access_token_secret = config.access_token_secret

# # Configuración de las credenciales de Llama Index
# bearer_token = config.bearer_token
# openai_api_key = config.OPENAI_API_KEY

# def search_twitter_and_summarize(topic):
#     # Autenticación de Twitter
#     auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
#     auth.set_access_token(access_token, access_token_secret)

#     # Creación del objeto API de Twitter
#     api = tweepy.API(auth)

#     # Realizar la búsqueda en Twitter
#     tweets = api.search_tweets(q=topic, count=5)

#     # Obtener los textos de los tweets
#     tweet_texts = [tweet.text for tweet in tweets]

#     # Inicializar el objeto TwitterTweetReader
#     twitter_loader = TwitterTweetReader(bearer_token=bearer_token)

#     # Cargar los tweets en Llama Index
#     documents = twitter_loader.load_data(texts=tweet_texts)

#     # Crear el template de la pregunta y respuesta
#     template = "¿Cuál es la información más destacada sobre {}?"
#     question = template.format(topic)
#     answer_prompt = QuestionAnswerPrompt(question)

#     # Inicializar el predictor de LLM
#     llm_predictor = LLMPredictor(llm=OpenAI(temperature=0, model_name="text-davinci-003", openai_api_key=openai_api_key))

#     # Crear el índice de Llama Index
#     index = GPTSimpleVectorIndex(documents)

#     # Realizar la búsqueda y obtener la respuesta destacada
#     response = index.query(question, text_qa_template=answer_prompt)

#     # Devolver la respuesta destacada
#     return response

# # Ejemplo de uso
# topic = "BTC"
# response = search_twitter_and_summarize(topic)
# print(response)

from transformers import MarianMTModel, MarianTokenizer
import torch

# Modelo para traducir texto usado más adelante
modelo = MarianMTModel.from_pretrained("Helsinki-NLP/opus-mt-en-es")
tokenizador = MarianTokenizer.from_pretrained("Helsinki-NLP/opus-mt-en-es")

# Función para traducir texto usada más adelante
def traducir_texto(texto, modelo, tokenizador):
    entrada = tokenizador(texto, return_tensors="pt", truncation=True)
    salida = modelo.generate(**entrada)
    texto_traducido = tokenizador.decode(salida[0], skip_special_tokens=True)
    return texto_traducido

# Seleccionamos modelo y numero de tokens
llm = OpenAI(model_name='gpt-4', max_tokens=5000)

# Elegir modelo a usar en LLMPredictor
llm_predictor = LLMPredictor(llm=llm)

# Guardar el LLMPredictor en la variable ServiceContext
service_context = ServiceContext.from_defaults(llm_predictor=llm_predictor)

# Seleccionar la ruta donde se va a cargar el índice
storage_context = StorageContext.from_defaults(persist_dir="./storage")
index = load_index_from_storage(storage_context)
query_engine = index.as_query_engine()

st.set_page_config(page_title="Crypto Analyst", page_icon="🪙")

from PIL import Image

# Cargar el logo
logo_path = "logo/CryptoAnalyst.png"
logo = Image.open(logo_path)

# Redimensionar el logo a un tamaño más pequeño
logo = logo.resize((150, 150))  

# Mostrar el logo en la aplicación
st.image(logo)

# Aplicar bordes redondeados al logo con CSS
st.markdown(
    """
    <style>
        img {
            border-radius: 50%;   
        }
        
    </style>
    """,
    unsafe_allow_html=True
)


st.title('Crypto Market Analyst')

st.header("Crypto Market Insights, Simplified")

st.text("Las criptomonedas disponibles actualmente son: BTC, ETH, SOL, XRP y ADA")

report_type = st.selectbox(
    'Que tipo de análisis desea?',
    ('Análisis individual', 'Análisis competitivo (Una vs Otra)'))

#Análisis individual
if report_type == 'Análisis individual':
    symbol = st.text_input("Criptomoneda a analizar")

    if symbol:
        with st.spinner(f'Generando análisis para {symbol}...'):
            response = query_engine.query(f"Write a report on the outlook for {symbol} cryptocurrency for the coming months. Be sure to include potential risks as well as the main keypoints.")
            
            response_eng = st.info(response)
            if st.button("Traducir (solo primeras líneas)"):
                texto_traducido = traducir_texto(response.response, modelo, tokenizador)
                response_eng.info(texto_traducido)
                if st.button("Deshacer traducción (mostrar todo el texto)"):
                    response_eng.info(response)

#Análisis competitivo
if report_type == 'Análisis competitivo (Una vs Otra)':
    symbol1 = st.text_input("Criptomoneda a analizar 1")
    symbol2 = st.text_input("Criptomoneda a analizar 2")

    if symbol1 and symbol2:
        with st.spinner(f'Generando análisis para {symbol1} vs {symbol2}...'):
            response = query_engine.query(f"Write a report on the competition between {symbol1} cryptocurrency and {symbol2} cryptocurrency for the coming months.")
            
            response_eng = st.info(response)
            if st.button("Traducir (solo primeras líneas)"):
                texto_traducido = traducir_texto(response.response, modelo, tokenizador)
                response_eng.info(texto_traducido)
                if st.button("Deshacer traducción (mostrar todo el texto)"):
                    response_eng.info(response)





